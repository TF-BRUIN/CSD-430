package beansPackage;

import java.sql.*;
import java.util.*;

public class JDSPbean implements java.io.Serializable {
	
	String url = "jdbc:mysql://localhost:3306/csd430?user=student1&password=pass";
	private Connection connection;
	// took me way too long to remember I can declare things up here
	
	public JDSPbean() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(url);
		}
		catch (Exception e) {
			System.out.println("ERROR - Could not connect to MySQL.");
			e.printStackTrace();
			System.exit(0);
		} // copied most of this code from a previous class to make sure JDSP worked properly
	}
	
	public Map<String, String> getRecord(int id) {
		Map<String, String> record = new HashMap<>();
		try {
			String request = "SELECT * FROM truman_movies_data WHERE ID = " + id;
			Statement statement = connection.createStatement(
	                ResultSet.TYPE_SCROLL_INSENSITIVE,
	                ResultSet.CONCUR_UPDATABLE
	                // I dunno if these are necessary, but decided to include them to be safe
	        );
			
			ResultSet results = statement.executeQuery(request);
			if (results.next()) {
				record.put("primaryKey",results.getString("ID"));
				record.put("movieName",results.getString("MOVIENAME"));
				record.put("releaseYear",results.getString("RELEASEYEAR"));
				record.put("director",results.getString("DIRECTOR"));
				record.put("imdbScore",results.getString("IMDBSCORE"));
				// I forget why I made all the mysql columns all-caps
			}
			
			results.close();
			statement.close();
		} catch (Exception e) {
			System.out.println("ERROR - Could not execute request.");
			e.printStackTrace();
			System.exit(0);
		}
		return record;
	}
	
	public void addRecord(String movieName, int releaseYear, String director, float imdbScore) {
		try {
			String additionRequest = 
					//"INSERT INTO truman_movies_data VALUES (NULL,'The Godfather',1972,'Francis Ford Coppola',9.2);";
					"INSERT INTO truman_movies_data VALUES (NULL,'" + 
							// had to do a lot of experimenting with the MySQL database in order to make this work
					movieName + "','" + 
					releaseYear + "','" + 
					director + "','" + 
					imdbScore + "');"; // figuring out the quotation marks for this request was a real pain
			System.out.println("REQUEST IS: " + additionRequest); // debug test to see if the constructed statement is proper
			Statement statement = connection.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
	                ResultSet.CONCUR_UPDATABLE
			);
			statement.executeUpdate(additionRequest);
			
			statement.close();
		} catch (Exception e) {
			System.out.println("ERROR - Could not execute request.");
			e.printStackTrace();
			System.exit(0);
		}
	} 
	
	public List<Map<String, String>> returnAllRecords() { 
		// originally I was gonna have both adding a new record and returning all records be the same class,
		// but this is SO much cleaner
		List<Map<String, String>> table = new ArrayList<>();
		try {
			String request = "SELECT * FROM truman_movies_data";
			Statement statement = connection.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
	                ResultSet.CONCUR_UPDATABLE
			); // theoretically, now I'm wondering if I could put the try/catch block to establish statement 
				// next to the url and connection statements
			// something to revise next week, maybe
			ResultSet results = statement.executeQuery(request);
			
			while (results.next()) {
				Map<String, String> holderRow = new HashMap<>();
				holderRow.put("id", results.getString("ID"));
				holderRow.put("movieName", results.getString("MOVIENAME"));
				holderRow.put("releaseYear", results.getString("RELEASEYEAR"));
				holderRow.put("director", results.getString("DIRECTOR"));
				holderRow.put("imdbScore", results.getString("IMDBSCORE"));
	            table.add(holderRow);
			} // at first I was worried that this code wouldn't reset and would get longer and longer, 
			// but it clears up without me needing to add anything special
			
			results.close();
			statement.close();
		} catch (Exception e) {
			System.out.println("ERROR - Could not execute request.");
			e.printStackTrace();
			System.exit(0);
		}
		return table;
	}
}






