package javaBeansPackage;

public class JavaBean implements java.io.Serializable{
	// for some reason, this line throws up a minor error, but it works fine as-is

	// TESTING STUFF, WAS FOLLOWING BELLEVUE VIDEO TO LEARN HOW TO USE JAVABEANS //
	
	//private String VAR;
	//
	//public JavaBean() {
	//	VAR = "TEST TEST TEST";
	//}
	//
	//public void setVar(String s) {
	//	VAR = s;
	//}
	//
	//public String getVar() {
	//	return VAR;
	//}

	private String title01;
	private String author01;
	private String date01;
	private String title02;
	private String author02;
	private String date02;
	private String title03;
	private String author03;
	private String date03;
	private String title04;
	private String author04;
	private String date04;
	private String title05;
	private String author05;
	private String date05; 
	
	// this is a very brute-force method of doing this,
	// but I figured this was the simplest way to make sure
	// this bean worked
	
	public JavaBean() { // at least i can declare all of these at once
		title01 = "Book of Bill";
		author01 = "Alex Hirsch";
		date01 = "2024";
		
		title02 = "House of Leaves";
		author02 = "Mark Z. Danielewski";
		date02 = "2000";
		
		title03 = "The Martian";
		author03 = "Andy Weir";
		date03 = "2011 & 2014";
		
		title04 = "Blood Meridian";
		author04 = "Cormac McCarthy";
		date04 = "1985";
		
		title05 = "Skeleton Crew";
		author05 = "Stephen King";
		date05 = "1985";
	}
	
	// I really hated to do this in such a brute-force way, but creating a more dynamic way to combine all
	// getter methods into a singular getter method would be way more complex than I know how to do
	
	// maybe that's a project I can do for the redo assignment?
	
	// these are all extremely normal getter methods, just a lot of them
	public String getTitle01() {
		return title01;
	}
	public String getAuthor01() {
		return author01;
	}
	public String getDate01() {
		return date01;
	}
	/// ----- LEAVING SPACE -----  //
	public String getTitle02() {
		return title02;
	}
	public String getAuthor02() {
		return author02;
	}
	public String getDate02() {
		return date02;
	}
	/// ----- LEAVING SPACE ----- //
	public String getTitle03() {
		return title03;
	}
	public String getAuthor03() {
		return author03;
	}
	public String getDate03() {
		return date03;
	}
	/// ----- LEAVING SPACE ----- //
	public String getTitle04() {
		return title04;
	}
	public String getAuthor04() {
		return author04;
	}
	public String getDate04() {
		return date04;
	}
	/// ----- LEAVING SPACE ----- //
	public String getTitle05() {
		return title05;
	}
	public String getAuthor05() {
		return author05;
	}
	public String getDate05() {
		return date05;
	}
}




