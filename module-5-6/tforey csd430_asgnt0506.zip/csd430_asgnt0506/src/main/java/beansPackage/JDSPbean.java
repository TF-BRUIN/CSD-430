package beansPackage;

import java.sql.*;
import java.util.*;

public class JDSPbean implements java.io.Serializable {
	
	String url = "jdbc:mysql://localhost:3306/csd430?user=student1&password=pass";
	private Connection connection;
	// took me way too long to remember I can declare things up here
	
	//private int primaryKey;
	//private String movieName;
	//private int releaseYear;
	//private String directorName;
	//private float imdbScore;
	// thought I would need these, but managed to simplify it a lot
	
	public JDSPbean() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(url);
		}
		catch (Exception e) {
			System.out.println("ERROR - Could not connect to MySQL.");
			e.printStackTrace();
			System.exit(0);
		} // copied most of this code from a previous class to make sure JDSP worked properly
	}
	
	public Map<String, String> getRecord(int id) {
		Map<String, String> record = new HashMap<>();
		try {
			String request = "SELECT * FROM truman_movies_data WHERE ID = " + id;
			Statement statement = connection.createStatement(
	                ResultSet.TYPE_SCROLL_INSENSITIVE,
	                ResultSet.CONCUR_UPDATABLE
	                // I dunno if these are necessary, but decided to include them to be safe
	        );
			ResultSet results = statement.executeQuery(request);
			if (results.next()) {
				record.put("primaryKey",results.getString("ID"));
				record.put("movieName",results.getString("MOVIENAME"));
				record.put("releaseYear",results.getString("RELEASEYEAR"));
				record.put("director",results.getString("DIRECTOR"));
				record.put("imdbScore",results.getString("IMDBSCORE"));
				// I forget why I made all the mysql columns all-caps
			}
			results.close();
		} catch (Exception e) {
			System.out.println("ERROR - Could not execute request.");
			e.printStackTrace();
			System.exit(0);
		}
		return record;
	}
}






